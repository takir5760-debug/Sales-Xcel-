import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import * as XLSX from 'xlsx';

type EditableKey = 'date' | 'item' | 'rate' | 'sold' | 'qty';
type CellValue = number | '';
interface LedgerRow {
  id: number;
  date: string;
  item: string;
  rate: CellValue;
  sold: CellValue;
  qty: CellValue;
}
interface Totals {
  rate: number;
  sold: number;
  qty: number;
  profit: number;
  loss: number;
  cash: number;
}

const TEMPLATE_PATH = '/BusinessBashundhara.xlsx';
const STORAGE_KEY = 'bashundhara-ledger-v1';
const HEADERS = ['Date', 'Item', 'Rate', 'Sold', 'Qty', 'Profit', 'Loss', 'Hand cash', 'Total Product Costing'];
const INITIAL_ROW_COUNT = 29;
const numberFormat = new Intl.NumberFormat('en-IN', { maximumFractionDigits: 2 });

function isEmpty(value: unknown): boolean {
  return value === undefined || value === null || value === '';
}

function numberValue(value: unknown): CellValue {
  if (isEmpty(value)) return '';
  const parsed = typeof value === 'number' ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : '';
}

function localDateTime(value: unknown): string {
  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    const pad = (n: number) => String(n).padStart(2, '0');
    return `${value.getFullYear()}-${pad(value.getMonth() + 1)}-${pad(value.getDate())}T${pad(value.getHours())}:${pad(value.getMinutes())}`;
  }
  if (typeof value === 'number') {
    const parsed = XLSX.SSF.parse_date_code(value);
    if (parsed) {
      const pad = (n: number) => String(n).padStart(2, '0');
      return `${parsed.y}-${pad(parsed.m)}-${pad(parsed.d)}T${pad(parsed.H)}:${pad(parsed.M)}`;
    }
  }
  if (typeof value === 'string' && value.trim()) {
    const date = new Date(value);
    if (!Number.isNaN(date.getTime())) {
      const pad = (n: number) => String(n).padStart(2, '0');
      return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
    }
  }
  return '';
}

function valueAt(sheet: XLSX.WorkSheet, row: number, col: number): unknown {
  return sheet[XLSX.utils.encode_cell({ r: row, c: col })]?.v;
}

function validateSheet(sheet: XLSX.WorkSheet): boolean {
  return HEADERS.every((label, col) => String(valueAt(sheet, 0, col) ?? '').trim().toLowerCase() === label.toLowerCase());
}

function extractRows(sheet: XLSX.WorkSheet): LedgerRow[] {
  const bounds = sheet['!ref'] ? XLSX.utils.decode_range(sheet['!ref']) : { e: { r: 30, c: 8 } };
  let highestRelevantRow = 1;
  for (let r = 1; r <= Math.max(bounds.e.r, 30); r += 1) {
    const hasValue = Array.from({ length: 8 }, (_, c) => sheet[XLSX.utils.encode_cell({ r, c })])
      .some((cell) => cell && (cell.v !== undefined || cell.f !== undefined));
    if (hasValue) highestRelevantRow = r;
  }
  const count = Math.max(INITIAL_ROW_COUNT, highestRelevantRow - 1);
  return Array.from({ length: count }, (_, index) => {
    const r = index + 1;
    return {
      id: index + 1,
      date: localDateTime(valueAt(sheet, r, 0)),
      item: isEmpty(valueAt(sheet, r, 1)) ? '' : String(valueAt(sheet, r, 1)),
      rate: numberValue(valueAt(sheet, r, 2)),
      sold: numberValue(valueAt(sheet, r, 3)),
      qty: numberValue(valueAt(sheet, r, 4)),
    };
  });
}

function calculate(row: LedgerRow) {
  const rate = Number(row.rate) || 0;
  const sold = Number(row.sold) || 0;
  const qty = Number(row.qty) || 0;
  return {
    profit: Math.max((sold - rate) * qty, 0),
    loss: Math.max((rate - sold) * qty, 0),
    cash: sold * qty,
  };
}

function summarize(rows: LedgerRow[]): Totals {
  return rows.reduce<Totals>((sum, row) => {
    const rate = Number(row.rate) || 0;
    const sold = Number(row.sold) || 0;
    const qty = Number(row.qty) || 0;
    const result = calculate(row);
    sum.rate += rate * qty;
    sum.sold += sold * qty;
    sum.qty += qty;
    sum.profit += result.profit;
    sum.loss += result.loss;
    sum.cash += result.cash;
    return sum;
  }, { rate: 0, sold: 0, qty: 0, profit: 0, loss: 0, cash: 0 });
}

function money(value: number): string {
  return `৳${numberFormat.format(value)}`;
}

function numberText(value: number): string {
  return numberFormat.format(value);
}

function setCell(sheet: XLSX.WorkSheet, row: number, col: number, value: unknown) {
  const address = XLSX.utils.encode_cell({ r: row, c: col });
  const oldCell = sheet[address];
  if (isEmpty(value)) {
    delete sheet[address];
    return;
  }
  const cell: XLSX.CellObject = oldCell ? { ...oldCell } : { t: 's', v: '' };
  if (col === 0 && value instanceof Date) {
    cell.t = 'd';
    cell.v = value;
  } else if (typeof value === 'number') {
    cell.t = 'n';
    cell.v = value;
  } else {
    cell.t = 's';
    cell.v = String(value);
  }
  delete cell.f;
  sheet[address] = cell;
}

function setFormula(sheet: XLSX.WorkSheet, row: number, col: number, formula: string, cached: number) {
  const address = XLSX.utils.encode_cell({ r: row, c: col });
  const previous = sheet[address];
  sheet[address] = {
    ...(previous ?? { t: 'n' as const, v: 0 }),
    t: 'n',
    f: formula,
    v: Number.isFinite(cached) ? cached : 0,
  };
}

async function exportWorkbook(base: Uint8Array, rows: LedgerRow[], totals: Totals): Promise<ArrayBuffer> {
  const XLSXStyled = await import('xlsx-js-style');
  const workbook = XLSXStyled.read(base, { type: 'array', cellDates: true, cellStyles: true });
  const sheetName = workbook.SheetNames[0] ?? 'Sheet1';
  const sheet = workbook.Sheets[sheetName];
  if (!sheet) throw new Error('Excel workbook-এর প্রথম sheet খুঁজে পাওয়া যায়নি।');

  rows.forEach((row, index) => {
    const excelRow = index + 1;
    const date = row.date ? new Date(row.date) : '';
    setCell(sheet, excelRow, 0, date || '');
    setCell(sheet, excelRow, 1, row.item.trim());
    setCell(sheet, excelRow, 2, row.rate);
    setCell(sheet, excelRow, 3, row.sold);
    setCell(sheet, excelRow, 4, row.qty);
    const excelNumber = excelRow + 1;
    const result = calculate(row);
    setFormula(sheet, excelRow, 5, `IF((D${excelNumber}-C${excelNumber})*E${excelNumber}>0,(D${excelNumber}-C${excelNumber})*E${excelNumber},0)`, result.profit);
    setFormula(sheet, excelRow, 6, `IF(C${excelNumber}>D${excelNumber},(C${excelNumber}-D${excelNumber})*E${excelNumber},0)`, result.loss);
    setFormula(sheet, excelRow, 7, `D${excelNumber}*E${excelNumber}`, result.cash);
  });

  const totalSheetRow = rows.length + 1;
  setCell(sheet, totalSheetRow, 0, 'Total');
  for (let col = 1; col <= 8; col += 1) {
    if (col !== 1 && col !== 8) delete sheet[XLSX.utils.encode_cell({ r: totalSheetRow, c: col })];
  }
  const firstDataRow = 2;
  const lastDataRow = rows.length + 1;
  setFormula(sheet, totalSheetRow, 2, `SUMPRODUCT(C${firstDataRow}:C${lastDataRow},E${firstDataRow}:E${lastDataRow})`, totals.rate);
  setFormula(sheet, totalSheetRow, 3, `SUMPRODUCT(D${firstDataRow}:D${lastDataRow},E${firstDataRow}:E${lastDataRow})`, totals.sold);
  setFormula(sheet, totalSheetRow, 4, `SUM(E${firstDataRow}:E${lastDataRow})`, totals.qty);
  setFormula(sheet, totalSheetRow, 5, `SUM(F${firstDataRow}:F${lastDataRow})`, totals.profit);
  setFormula(sheet, totalSheetRow, 6, `SUM(G${firstDataRow}:G${lastDataRow})`, totals.loss);
  setFormula(sheet, totalSheetRow, 7, `SUM(H${firstDataRow}:H${lastDataRow})`, totals.cash);
  sheet['!ref'] = `A1:I${totalSheetRow + 1}`;

  const thinBorder = {
    top: { style: 'thin', color: { rgb: 'FFD4DFE2' } },
    bottom: { style: 'thin', color: { rgb: 'FFD4DFE2' } },
    left: { style: 'thin', color: { rgb: 'FFD4DFE2' } },
    right: { style: 'thin', color: { rgb: 'FFD4DFE2' } },
  };
  const headerStyle = {
    fill: { patternType: 'solid', fgColor: { rgb: 'FF4BACC6' } },
    font: { bold: true, color: { rgb: 'FFFFFFFF' } },
    alignment: { horizontal: 'center', vertical: 'center' },
    border: thinBorder,
  };
  const totalStyle = (col: number) => ({
    fill: { patternType: 'solid', fgColor: { rgb: 'FF4BACC6' } },
    font: { bold: true, color: { rgb: 'FFFFFFFF' } },
    alignment: { horizontal: 'center', vertical: 'center' },
    border: thinBorder,
    numFmt: col === 0 ? 'General' : col === 1 ? '@' : col === 2 ? '#,##0.00 "Tk"' : 'General',
  });
  const bodyStyle = (col: number) => ({
    fill: { patternType: 'solid', fgColor: { rgb: 'FFE9F1F5' } },
    font: { bold: col === 0, color: { rgb: 'FF000000' } },
    alignment: { horizontal: 'center', vertical: 'center' },
    border: thinBorder,
    numFmt: col === 0 ? 'mm/dd/yyyy "T -" hh:mm' : col === 1 ? '@' : col === 2 ? '#,##0.00 "Tk"' : 'General',
  });
  for (let r = 0; r <= totalSheetRow; r += 1) {
    for (let c = 0; c < HEADERS.length; c += 1) {
      const address = XLSX.utils.encode_cell({ r, c });
      const cell = sheet[address] ?? { t: 's' as const, v: '' };
      cell.s = r === 0 ? headerStyle : r === totalSheetRow ? totalStyle(c) : bodyStyle(c);
      sheet[address] = cell;
    }
  }
  sheet['!cols'] = [
    { wch: 22 }, { wch: 15 }, { wch: 14 }, { wch: 13 }, { wch: 9 },
    { wch: 12 }, { wch: 12 }, { wch: 15 }, { wch: 23 },
  ];

  const output = XLSXStyled.write(workbook, { bookType: 'xlsx', type: 'array', compression: true, cellDates: true });
  return output as ArrayBuffer;
}

function App() {
  const [rows, setRows] = useState<LedgerRow[]>([]);
  const totals = useMemo(() => summarize(rows), [rows]);
  const [loaded, setLoaded] = useState(false);
  const [busy, setBusy] = useState(false);
  const [sourceName, setSourceName] = useState('BusinessBashundhara.xlsx');
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const workbookBytes = useRef<Uint8Array | null>(null);
  const fileInput = useRef<HTMLInputElement>(null);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const response = await fetch(TEMPLATE_PATH);
        if (!response.ok) throw new Error('প্রাথমিক Excel file পাওয়া যায়নি।');
        const bytes = new Uint8Array(await response.arrayBuffer());
        const workbook = XLSX.read(bytes, { type: 'array', cellDates: true, cellStyles: true });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        if (!sheet || !validateSheet(sheet)) throw new Error('প্রাথমিক workbook-এর কলামগুলো পড়া যায়নি।');
        const parsed = extractRows(sheet);
        workbookBytes.current = bytes;
        if (!active) return;
        let savedRows: LedgerRow[] | null = null;
        try {
          const stored = localStorage.getItem(STORAGE_KEY);
          if (stored) {
            const candidate = JSON.parse(stored);
            if (Array.isArray(candidate) && candidate.every((item) => item && typeof item === 'object')) savedRows = candidate;
          }
        } catch {
          localStorage.removeItem(STORAGE_KEY);
        }
        setRows(savedRows?.length ? savedRows : parsed);
      } catch (loadError) {
        if (active) {
          setError(loadError instanceof Error ? loadError.message : 'Excel file লোড করতে সমস্যা হয়েছে।');
          setRows(Array.from({ length: INITIAL_ROW_COUNT }, (_, id) => ({ id: id + 1, date: '', item: '', rate: '', sold: '', qty: '' })));
        }
      } finally {
        if (active) setLoaded(true);
      }
    })();
    return () => { active = false; };
  }, []);

  useEffect(() => {
    if (!loaded) return;
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(rows)); } catch { /* Browser storage can be disabled. */ }
  }, [rows, loaded]);

  const filledCount = useMemo(() => rows.filter((row) => row.date || row.item.trim() || row.rate !== '' || row.sold !== '' || row.qty !== '').length, [rows]);

  const updateCell = useCallback((id: number, key: EditableKey, value: string) => {
    setRows((current) => current.map((row) => {
      if (row.id !== id) return row;
      const nextValue: string | number = key === 'rate' || key === 'sold' || key === 'qty'
        ? (value.trim() === '' || !Number.isFinite(Number(value)) ? '' : Number(value))
        : value;
      return { ...row, [key]: nextValue } as LedgerRow;
    }));
    setNotice('');
  }, []);

  const importWorkbook = async (file?: File) => {
    if (!file) return;
    setError('');
    setNotice('');
    try {
      const bytes = new Uint8Array(await file.arrayBuffer());
      const workbook = XLSX.read(bytes, { type: 'array', cellDates: true, cellStyles: true });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      if (!sheet || !validateSheet(sheet)) {
        throw new Error('এই file-এর প্রথম sheet-এ প্রত্যাশিত ৯টি column header পাওয়া যায়নি।');
      }
      const nextRows = extractRows(sheet);
      workbookBytes.current = bytes;
      setRows(nextRows);
      setSourceName(file.name);
      setNotice(`${file.name} থেকে ${nextRows.length}টি row লোড হয়েছে।`);
    } catch (importError) {
      setError(importError instanceof Error ? importError.message : 'Excel file import করা যায়নি।');
    } finally {
      if (fileInput.current) fileInput.current.value = '';
    }
  };

  const addRow = () => {
    if (rows.length >= 500) {
      setError('সর্বোচ্চ ৫০০টি data row রাখা যাবে।');
      return;
    }
    const nextId = Math.max(0, ...rows.map((row) => row.id)) + 1;
    setRows((current) => [...current, { id: nextId, date: '', item: '', rate: '', sold: '', qty: '' }]);
    setNotice('');
  };

  const saveExcel = async () => {
    if (!workbookBytes.current) {
      setError('প্রাথমিক Excel file এখনো প্রস্তুত নয়। একটু পরে আবার চেষ্টা করুন।');
      return;
    }
    setBusy(true);
    setError('');
    setNotice('');
    try {
      const output = await exportWorkbook(workbookBytes.current, rows, totals);
      const blob = new Blob([output], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = `Bashundhara-Sales-${new Date().toISOString().slice(0, 10)}.xlsx`;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      URL.revokeObjectURL(url);
      setNotice('আপনার সম্পাদিত Excel file ডাউনলোড হয়েছে। সূত্রগুলো file-এ রাখা আছে।');
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : 'Excel file তৈরি করা যায়নি।');
    } finally {
      setBusy(false);
    }
  };

  return (
    <main className="app-shell">
      <header className="topbar">
        <a className="brand" href="#top" aria-label="Bashundhara Sales Ledger home">
          <span className="brand-mark" aria-hidden="true"><span>B</span><i /></span>
          <span className="brand-copy"><strong>BASHUNDHARA</strong><small>SALES LEDGER</small></span>
        </a>
        <div className="topbar-right">
          <span className="sync-label"><span className="sync-dot" />{loaded ? 'সব পরিবর্তন সংরক্ষিত' : 'ফাইল খোলা হচ্ছে'}</span>
          <span className="avatar" aria-label="Business Bashundhara">BB</span>
        </div>
      </header>

      <section className="workspace" id="top">
        <div className="page-heading">
          <div>
            <div className="eyebrow"><span className="eyebrow-line" />DAILY BUSINESS RECORD</div>
            <h1>বিক্রয় হিসাব</h1>
            <p className="subtitle">এক জায়গায় পণ্যের বিক্রি, লাভ ও নগদের হিসাব রাখুন।</p>
          </div>
          <div className="date-chip"><span className="date-icon" aria-hidden="true">▦</span><span><small>আজকের তারিখ</small><strong>{new Intl.DateTimeFormat('bn-BD', { day: 'numeric', month: 'long', year: 'numeric' }).format(new Date())}</strong></span></div>
        </div>

        <section className="summary-grid" aria-label="হিসাবের সারাংশ">
          <article className="summary-card summary-primary">
            <div className="summary-top"><span>মোট লাভ</span><span className="summary-icon profit-icon" aria-hidden="true">↗</span></div>
            <strong className="summary-value">{money(totals.profit)}</strong>
            <span className="summary-foot"><span className="positive-dot" /> সূত্র অনুযায়ী স্বয়ংক্রিয় হিসাব</span>
          </article>
          <article className="summary-card">
            <div className="summary-top"><span>মোট Hand cash</span><span className="summary-icon cash-icon" aria-hidden="true">৳</span></div>
            <strong className="summary-value">{money(totals.cash)}</strong>
            <span className="summary-foot">বিক্রয় মূল্য × পরিমাণ</span>
          </article>
          <article className="summary-card">
            <div className="summary-top"><span>মোট Loss</span><span className="summary-icon loss-icon" aria-hidden="true">↘</span></div>
            <strong className="summary-value">{money(totals.loss)}</strong>
            <span className="summary-foot">ক্রয়মূল্য বিক্রয়মূল্যের বেশি হলে</span>
          </article>
          <article className="summary-card summary-count">
            <div className="summary-top"><span>এন্ট্রি</span><span className="summary-icon count-icon" aria-hidden="true">#</span></div>
            <strong className="summary-value">{numberText(filledCount)} <small>/ {numberText(rows.length)}</small></strong>
            <span className="summary-foot">ব্যবহৃত ডেটা সারি</span>
          </article>
        </section>

        <section className="ledger-panel" aria-label="সম্পাদনাযোগ্য বিক্রয় টেবিল">
          <div className="ledger-heading">
            <div className="ledger-title-wrap">
              <div className="ledger-title-row"><h2>দৈনিক লেজার</h2><span className="row-badge">{numberText(rows.length)} ROWS</span></div>
              <p>যে ঘরটি বদলাতে চান, সেটিতে ক্লিক করে লিখুন। হিসাব সঙ্গে সঙ্গে আপডেট হবে।</p>
            </div>
            <div className="toolbar">
              <input ref={fileInput} className="visually-hidden" type="file" accept=".xlsx,.xls" onChange={(event) => void importWorkbook(event.target.files?.[0])} aria-label="Excel file import" />
              <button className="button button-secondary" onClick={() => fileInput.current?.click()} title={`বর্তমান উৎস: ${sourceName}`}>
                <span aria-hidden="true">↑</span> Excel খুলুন
              </button>
              <button className="button button-secondary add-button" onClick={addRow}><span aria-hidden="true">＋</span> সারি যোগ</button>
              <button className="button button-primary" onClick={saveExcel} disabled={!loaded || busy}>
                <span aria-hidden="true">↓</span> {busy ? 'তৈরি হচ্ছে…' : 'Excel সেভ করুন'}
              </button>
            </div>
          </div>

          {(notice || error) && <div className={`notice ${error ? 'notice-error' : 'notice-success'}`} role={error ? 'alert' : 'status'}>{error || notice}<button onClick={() => { setError(''); setNotice(''); }} aria-label="বার্তা বন্ধ করুন">×</button></div>}

          <div className="table-scroll">
            <table className="ledger-table">
              <thead>
                <tr>
                  {HEADERS.map((header) => <th key={header} className={`col-${header.toLowerCase().replaceAll(' ', '-')}`} scope="col">{header}</th>)}
                </tr>
              </thead>
              <tbody>
                {rows.map((row, index) => {
                  const result = calculate(row);
                  const excelRow = index + 2;
                  return (
                    <tr key={row.id}>
                      <td><input className="cell-input date-input" type="datetime-local" value={row.date} onChange={(event) => updateCell(row.id, 'date', event.target.value)} aria-label={`সারি ${excelRow}, Date`} /></td>
                      <td><input className="cell-input item-input" type="text" value={row.item} onChange={(event) => updateCell(row.id, 'item', event.target.value)} placeholder="পণ্যের নাম" aria-label={`সারি ${excelRow}, Item`} /></td>
                      <td><input className="cell-input numeric-input" type="number" step="any" value={row.rate} onChange={(event) => updateCell(row.id, 'rate', event.target.value)} placeholder="—" aria-label={`সারি ${excelRow}, Rate`} /></td>
                      <td><input className="cell-input numeric-input" type="number" step="any" value={row.sold} onChange={(event) => updateCell(row.id, 'sold', event.target.value)} placeholder="—" aria-label={`সারি ${excelRow}, Sold`} /></td>
                      <td><input className="cell-input numeric-input" type="number" step="any" value={row.qty} onChange={(event) => updateCell(row.id, 'qty', event.target.value)} placeholder="—" aria-label={`সারি ${excelRow}, Qty`} /></td>
                      <td className="formula-cell formula-profit" title={`=IF((D${excelRow}-C${excelRow})*E${excelRow}>0,(D${excelRow}-C${excelRow})*E${excelRow},0)`}>{numberText(result.profit)}</td>
                      <td className="formula-cell formula-loss" title={`=IF(C${excelRow}>D${excelRow},(C${excelRow}-D${excelRow})*E${excelRow},0)`}>{numberText(result.loss)}</td>
                      <td className="formula-cell formula-cash" title={`=D${excelRow}*E${excelRow}`}>{numberText(result.cash)}</td>
                      <td className="unmapped-cell" title="মূল Excel-এ এই কলামের জন্য কোনো সূত্র নেই">—</td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr>
                  <th scope="row">Total</th>
                  <td />
                  <td className="total-cell" title={`=SUMPRODUCT(C2:C${rows.length + 1},E2:E${rows.length + 1})`}>{numberText(totals.rate)}</td>
                  <td className="total-cell" title={`=SUMPRODUCT(D2:D${rows.length + 1},E2:E${rows.length + 1})`}>{numberText(totals.sold)}</td>
                  <td className="total-cell" title={`=SUM(E2:E${rows.length + 1})`}>{numberText(totals.qty)}</td>
                  <td className="total-cell total-profit" title={`=SUM(F2:F${rows.length + 1})`}>{numberText(totals.profit)}</td>
                  <td className="total-cell total-loss" title={`=SUM(G2:G${rows.length + 1})`}>{numberText(totals.loss)}</td>
                  <td className="total-cell total-cash" title={`=SUM(H2:H${rows.length + 1})`}>{numberText(totals.cash)}</td>
                  <td />
                </tr>
              </tfoot>
            </table>
          </div>
          <div className="ledger-footer"><span><i className="footer-indicator" /> সূত্রের ঘরগুলো স্বয়ংক্রিয় — সম্পাদনার প্রয়োজন নেই</span><span>মূল ফাইল: {sourceName}</span></div>
        </section>

        <footer className="page-footer">
          <span><span className="footer-brand-mark">B</span> Business Bashundhara · Sales Ledger</span>
          <span><kbd>Tip</kbd> Excel সেভ করলে একটি নতুন .xlsx ফাইল ডাউনলোড হবে</span>
        </footer>
      </section>
    </main>
  );
}

export default App;
