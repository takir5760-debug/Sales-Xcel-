# TODO

- [x] **Excel-সদৃশ বিক্রয় টেবিল ও লাইভ হিসাব:** `BusinessBashundhara.xlsx`-এর টেবিল অনুসরণ করে Date, Item, Rate, Sold, Qty, Profit, Loss, Hand cash এবং Total Product Costing কলাম দেখায়; ২–৩০ নম্বর ডেটা সারি ও শেষে Total সারি থাকে। ব্যবহারকারী সেলে ক্লিক করে ডেটা সম্পাদনা করতে পারেন এবং প্রতিটি পরিবর্তনের পর হিসাব তাৎক্ষণিকভাবে Excel-এর মতো আপডেট হয়। প্রতি সারিতে Profit হয় `IF((Sold-Rate)*Qty>0,(Sold-Rate)*Qty,0)`, Loss হয় `IF(Rate>Sold,(Rate-Sold)*Qty,0)` এবং Hand cash হয় `Sold*Qty`।
- [x] **মোট সারি ও Excel ফাইল রপ্তানি:** Total সারিতে Rate ও Sold-এর জন্য সংশ্লিষ্ট Qty range-সহ `SUMPRODUCT`, এবং Qty, Profit, Loss ও Hand cash-এর জন্য `SUM` হিসাব থাকে। Save/Export চাপলে সম্পাদিত ডেটা ও সংরক্ষিত Excel সূত্রসহ আলাদা `.xlsx` ফাইল ডাউনলোড হয়।
