# Bashundhara Sales Ledger

An Excel-like, editable sales ledger based on `BusinessBashundhara.xlsx`. The browser opens the supplied workbook as its starting point; the table keeps the original nine headers and supports editing Date, Item, Rate, Sold and Qty. Profit, Loss, Hand cash and the Total row update immediately. The Total Product Costing header is retained as in the source workbook; its data cells remain blank because the supplied workbook has no formula for that column.

## Run locally

```sh
pnpm install
pnpm dev
```

## Export

Choose **Excel সেভ করুন** to download a separate `.xlsx` workbook. The export starts from the workbook template and preserves the workbook's other sheets and original layout while writing the edited rows, row formulas and total formulas. The downloaded file contains cached calculation values as well as Excel formulas. **Excel খুলুন** can import another workbook with the same nine column headers.

All row data is kept in the browser's local storage on the current device/browser. No account or server database is required.
